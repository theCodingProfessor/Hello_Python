"""
Pro Tips: Blank Space with Python Comments
Clinton Garwood
September 2024
License: MIT
"""

# Pro Tip: Blank Space with Python Comments
print(f'\nPro Tip: Blank Space with Python Comments')

"""
The opening multi-line triple quotes " " " are on their own line
All the statements in the comment block are indented alike
The closing multi-line triple quotes " " " are on their own line
"""

# A single blank line above separates two blocks of comments from each other.
print(f'A single blank line should separate blocks of code.')

print(f'A single blank line must be at the end of the Python file.')
