"""
Pro Tips: Indenting and Nested Indentation in Python
Clinton Garwood
September 2024
License: MIT
"""

# Pro Tip: Indenting and Nested Indentation in Python
print(f'\nPro Tip: Indenting and Nested Indentation in Python')


"""
Python requires indented lines for nested statements.
Use either two (2) or (4) spaces (space bar = a space).
  This is two-spaces;
    this is four-spaces;
The key is to be consistent.
Use EITHER two (2) or four (4) the same in all your code.
if something == TRUE:
  this code runs
else:
  other code runs

if something == TRUE:
    this code runs
else:
    other code runs
"""


def function_indentation():
    # This line is aligned (indented) with the return statement
    if True:
        print(f'\tWe still indent when needed.')
    return


print(f'A single blank line MUST be at the end of the Python file.')
