"""
Pro Tips: Blank Lines in Python Code
Clinton Garwood
September 2024
License: MIT
"""

# Pro Tip: Blank Lines in Python Code
print(f'\nPro Tip: Blank Lines in Python Code')

# Use a single blank line to separate blocks of code or comments.

# A single blank line above separates the two comments from each other.
print(f'A single blank line should separate blocks of code.')


def this_function():
    # Two blank lines are required before a function `def` definition.
    print(f'\tPrinting hello from inside this_function.')
    # Two blank lines are required after a function `return`
    return


this_function()
print(f'A single blank line MUST be at the end of the Python file.')
