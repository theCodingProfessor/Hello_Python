# Simple Demo

print("Hello World")
print(f"\tSmores More Data")
