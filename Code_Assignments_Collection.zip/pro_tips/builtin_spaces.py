"""
Pro Tips: Spaces for Built-In Functions in Python
Clinton Garwood
September 2024
License: MIT
"""

# Pro Tip: Spaces for Built-In Functions in Python
print(f'\nSpaces for Built-In Functions in Python')

# Built-in function names, see print below, must touch their parenthesis ()
# WRONG -> print ()
# RIGHT -> print()
print()

# Function parameters see 'abc' and 'def', are seperated with a comma and space
# WRONG -> print('abc','def')
# RIGHT -> print('abc', 'def')
print('abc', 'def')

print(f'A single blank line must be at the end of the Python file.')
